

import Mobile from './mobile';

function Singlemobile() {
  return (
    <>
     <Mobile />
      
    </>
  );
}

export default Singlemobile;